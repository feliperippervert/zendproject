<?php
	namespace ExampleTests;
	
	
	require "/var/www/corollarium/" . DIRECTORY_SEPARATOR . "vendor" . DIRECTORY_SEPARATOR . "autoload.php";
	use PHPUnit\Framework\TestCase;
	use Example\Singleton;
	
	
	class SingletonTest extends TestCase
	{
		
		/**
		 * Função setUp instancia a classe Singleton
		 */		
		
		public function setUp()
		{
			$this->singleton = Singleton::getInstance();
		} 
			
				
		/**
		 * Verifica se ele está passando o valor correto do título default 
		 *
		 * @test
		 */		 
		public function testaOSetTittle()
		{
			
			$singleton = $this->singleton;
					
			$expected = $singleton->setTitle("Corollarium Teste");						
			$actual = $singleton->setTitle($this);
			
			//Compara o resultado esperado com o resultado real
			$this->assertEquals($expected, $actual);

		
		}
		
		/**
		 * Verifica se ele está passando o valor string correto para a construção do header 
		 *
		 * @test
		 */	
		public function testGetHeader()
		{			
			$singleton = $this->singleton;
			$headercontent = file_get_contents('/var/www/corollarium/lib/Example/template/header.php');
			
			$expected = '<header>' . $headercontent . '</header>';
			
			// Como o método testado é privado ele busca a função invokeMethod que torna o método acessível e busca seu retorno 
			$actual = $this->invokeMethod($singleton, 'getHeader', array('getHeader'));				 
			
			$this->assertEquals($expected, $actual);
		
		}	
		
		/**
		 * Verifica se ele está passando o valor string correto para a construção do footer 
		 *
		 * @test
		 */	
		public function testaOMetodoGetFooter()
		{			
			$singleton = $this->singleton;
			
			$footercontent = file_get_contents('/var/www/corollarium/lib/Example/template/footer.php');
			
			$expected = '<footer>' . $footercontent . '</footer>';
			$actual = $this->invokeMethod($singleton, 'getFooter', array('getFooter'));						 
			
			$this->assertEquals($expected, $actual);
		
		}	
		
		/**
		 * Verifica se ele está passando o valor string correto para a construção do header 
		 *
		 * @test
		 */	
		public function testaOMetodoGetMain()
		{			
			$singleton = $this->singleton;
						
			$expected = '<main>main content</main>';
			$actual = $this->invokeMethod($singleton, 'getMain', array('getMain'));
						
			$this->assertEquals($expected, $actual);
			
		}	
		
		/**
		 * 
		 * Verifica se ele está Montando o Body 
		 * 
		 * @test
		 */	
		public function testaOMetodoGetBody()
		{
			
			$singleton = $this->singleton;
			
			$actualMain = $this->invokeMethod($singleton, 'getMain', array('getMain'));	
			$actualHeader = $this->invokeMethod($singleton, 'getHeader', array('getHeader'));
			$actualFooter = $this->invokeMethod($singleton, 'getFooter', array('getFooter'));
						
			$expected = "<body>{$actualHeader}{$actualMain}{$actualFooter}</body>";
			$actual = $this->invokeMethod($singleton, 'getBody', array('getBody'));			
			
			$this->assertEquals($expected, $actual);
		
		}
		
		/**
		 * 
		 * Verifica se ele está Montando o Body
		 * 
		 * @test
		 */	
		public function testaOMetodogetHead()
		{
			
			$singleton = $this->singleton;			
			$assets = $this->invokeMethod($singleton, 'getAssets', array('getAssets'));
						
			$expected = "<head><title>Corollarium Teste</title>{$assets}</head>";						   
			$actual = $this->invokeMethod($singleton, 'getHead', array('getHead'));			
			
			$this->assertEquals($expected, $actual);
		
		}
		
		/**
		 * 
		 * Verifica se ele está renderizando a página 
		 * 
		 * Utiliza o método expectOutputString para comparar duas impressões diferentes na tela
		 * 
		 * @test
		 */	
		public function testaOMetodoRender()
		{
			
			$singleton = $this->singleton;
			
			$contentHead = $this->invokeMethod($singleton, 'getHead', array('getHead'));
			$contentBody = $this->invokeMethod($singleton, 'getBody', array('getBody'));
			
			$expected = "<!DOCTYPE html><html>{$contentHead}{$contentBody}</html>";						   
			$actual = $singleton->render();	
			
			$this->expectOutputString($expected);					  
		
		}
		
		
		/**
		 * 
		 * Método Invoke que torna acessíveis os métodos privados e protegidos da classe
		 * 
		 */	
		public function invokeMethod(&$object, $methodName, array $parameters = array())
		{
		    $reflection = new \ReflectionClass(get_class($object));
			
		    $method = $reflection->getMethod($methodName);
		    $method->setAccessible(true);
		
		    return $method->invokeArgs($object, $parameters);
		}
		
	}
