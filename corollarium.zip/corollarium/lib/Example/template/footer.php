    <footer class="footer">
      <div class="container">
        <p class="text-muted">Collarium footer</p>
      </div>
    </footer>