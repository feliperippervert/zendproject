    <nav class="navbar navbar-toggleable-md navbar-inverse bg-inverse fixed-top">
    <div class="container-fluid">
	    <div class="navbar-header">
	      <a class="navbar-brand" href="#">Collarium</a>
	    </div>
		    <ul class="nav navbar-nav">
		      <li><a href="#">Home</a></li>
		      <li><a href="#">Info</a></li>
		    </ul>

      </div>
    </nav>