<?php

namespace Example;

class Singleton 
{
    /**
     * @var Array
     */
    protected $assets = [];


    /**
     * @var String
     */
    protected $title = "Corollarium Teste";

    /**
     * Variável utilizada para armazenar o content do header do body
     *
     * @var String
     */
    protected $header = "";

    /**
     * Variável utilizada para armazenar o content do main do body
     *
     * @var String
     */
    protected $main = "";

    /**
     * Variável utilizada para armazenar o content do footer do body
     *
     * @var String
     */
    protected $footer = "";

    /**
     * Método construtor
     */
    protected function __construct()
    {}

    /**
     * Método clone
     */
    private function __clone()
    {}

    /**
     * Método wakeup
     */
    private function __wakeup()
    {}

    /**
     * Retorna a instância da classe
     *
     * @return Singleton A Instância única.
     */
    public static function getInstance()
    {
        static $instance = null;
        if (null === $instance) {
            $instance = new static();
        }

        return $instance;
    }

    /**
     * Adiciona asset no array de assets
     *
     * @param String $type Define qual tipo de asset será setado (CSS ou JS)
     * @param String $src Url de onde o arquivo se encontra
     * @return Singleton A Instância única.
     */
    public function appendAsset($type, $src)
    {
        // Adicionando asset no array
        $this->assets[$type][] = $src;
		return $this;
    }

    /**
     * Método utilizado para renderizar os assets(scripts js e styles css) no header do site
     *
     * @return String Retorna string com as tags html dos scripts e styles
     */
    private function getAssets()
    {
        $assetsReturn = '';
        // Verifica se há styles no array de assets
        if (isset($this->assets['css'])) {
            // foreach nos styles
            foreach ($this->assets['css'] as $src) {
                $assetsReturn .= '<link rel="stylesheet" href="'.$src.'"/>' . PHP_EOL;
            }
        }

        // Verifica se há scripts no array de assets
        if (isset($this->assets['js'])) {
            // foreach nos scripts
            foreach ($this->assets['js'] as $src) {
                $assetsReturn .= '<script src="'.$src.'" type="text/javascript"></script>' . PHP_EOL;
            }
        }
        return $assetsReturn;
    }

    /**
     * Método utilizado para setar o título da página
     *
     * @return Singleton A Instância única.
     */
    public function setTitle()
    {
        $title = "Corollarium Teste";
        return $title;
    }
	
    /**
     * Método utilizado retornar a tag head do site com o title e os assets
     *
     * @return String Retorna string a tag head completa
     */
    private function getHead()
    {
    	(string)$head = "<head><title>{$this->setTitle()}</title>{$this->getAssets()}</head>";
        return $head;
    }

    /**
     * Método utilizado para setar o conteúdo do body (header, main, footer)
     *
     * @return Singleton A Instância única.
     */
    public function setContent(\Closure $closureContent, $type, $content)
    {
        $this->{$type} .= $closureContent($content);
        return $this;
    }

    /**
     * Método utilizado retornar o header do body
     *
     * @return String Header do body
     */
    private function getHeader()
    {
        $header = "<header>{$this->header}</header>";

        return $header;
    }

    /**
     * Método utilizado retornar o main do body
     *
     * @return String Content do body
     */
    private function getMain()
    {
        $main = "<main>{$this->main}</main>";

        return $main;
    }

    /**
     * Método utilizado retornar o footer do body
     *
     * @return String Footer do body
     */
    private function getFooter()
    {
        $footer = "<footer>{$this->footer}</footer>";

        return $footer;
    }

    /**
     * Método utilizado retornar a tag body do site completo
     *
     * @return String Retorna string a tag body completa
     */
    private function getBody()
    {
        $body = "<body>{$this->getHeader()}{$this->getMain()}{$this->getFooter()}</body>";
		
        return $body;
    }

    /**
     * Método utilizado renderizar a página inteira. Ao ser chamdo já é feito o echo da página
     */
    public function render()
    {
        echo "<!DOCTYPE html><html>{$this->getHead()}{$this->getBody()}</html>";
    }
}

// --------------
// Começando construção da página
// --------------
$singleton = Singleton::getInstance();

// Setando title
$singleton->setTitle("Corollarium Teste");

// Inserindo Assets
$singleton->appendAsset('css', '/corollarium/assets/css/bootstrap-theme.css')
		  ->appendAsset('css', '/corollarium/assets/css/footer.css')
		  ->appendAsset('css', '/corollarium/assets/css/bootstrap.min.css')
		  ->appendAsset('css', '/corollarium/assets/css/bootstrap.css')
          ->appendAsset('js', '/corollarium/assets/js/bootstrap.js')
          ->appendAsset('js', '/corollarium/assets/js/bootstrap.min.js')
          ->appendAsset('js', '/corollarium/assets/js/npm.js');

// Criando closure que seta conteúdo do body (header, content ou footer)
$closureSetContent = function ($content) {
                            return file_get_contents($content);
                     };

$headercontent = '/var/www/corollarium/lib/Example/template/header.php';
$maincontent = '/var/www/corollarium/lib/Example/template/main.php';                   
$footercontent = '/var/www/corollarium/lib/Example/template/footer.php';

// Enviando closure para setar conteúdo da página
$singleton->setContent($closureSetContent, 'header', $headercontent)
          ->setContent($closureSetContent, 'main', $maincontent)
          ->setContent($closureSetContent, 'footer', $footercontent);

// --------------
// Renderizando a página toda
// --------------
$singleton->render();


